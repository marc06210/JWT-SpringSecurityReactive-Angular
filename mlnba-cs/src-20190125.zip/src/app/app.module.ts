import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { HttpClientModule } from '@angular/common/http';
import { FormsModule, FormBuilder } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SharedModule } from './shared/shared.module';

import { UserComponent, DialogDataExampleDialog } from './user/user.component';
import { UserService } from './user/user.service';
import { TeamService } from './team/team.service';
import { HomeComponent } from './home/home.component';
import { LoginComponent, PasswordDialog } from './login/login.component';
import { AppService } from './app.service';
import { TeamComponent, TeamDialog } from './team/team.component';
import { MatListModule } from '@angular/material/list';
import { MatSnackBarModule } from '@angular/material';


@NgModule({
  declarations: [
    AppComponent,
    UserComponent,
    DialogDataExampleDialog,
    PasswordDialog,
    TeamDialog,
    HomeComponent,
    LoginComponent,
    TeamComponent
  ],
  entryComponents: [DialogDataExampleDialog, TeamDialog, PasswordDialog],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,

    FormsModule,
    BrowserAnimationsModule,
    MatListModule,
    MatSnackBarModule,

    SharedModule
  ],
  providers: [AppService, UserService, TeamService, FormBuilder],
  bootstrap: [AppComponent]
})
export class AppModule { }
