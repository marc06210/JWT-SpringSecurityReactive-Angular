import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { User } from './models/user.model';

@Injectable()
export class AppService {

  authenticated = false;
  admin: boolean = false;

  constructor(private http: HttpClient) {
  }


  isAdmin(user :User): void {
      console.log('isadmin');
    this.admin = false

    if(user==null) {
        console.log('user is null')
        return ;
    }

    user.roles.forEach(role => {
        console.log('treating: ' + role.authority);
        if(role.authority=='joueur')
            this.admin = true;
    });

  }
  
}